import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import { useEffect, useRef, useState } from "react";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Platform from "./pages/Platform";
import CaseStudy from "./pages/CaseStudy";

function Router() {
  const [location] = useLocation();
  const [transitioning, setTransitioning] = useState(false);
  const [direction, setDirection] = useState<"forward" | "back">("forward");
  const previousLocation = useRef(location);

  useEffect(() => {
    const onPopState = () => { setDirection("back"); setTransitioning(true); window.setTimeout(() => setTransitioning(false), 620); };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  useEffect(() => {
    if (!transitioning) { setDirection("forward"); return; }
    const timer = window.setTimeout(() => setTransitioning(false), 620);
    return () => window.clearTimeout(timer);
  }, [location]);

  useEffect(() => {
    if (previousLocation.current !== location) {
      setDirection("forward");
      setTransitioning(true);
      previousLocation.current = location;
    }
  }, [location]);

  return (
    <div className={`route-stage ${transitioning ? "is-transitioning" : ""} route-${direction}`} data-route={location}>
      <div className="route-portal" aria-hidden="true"><span className="route-portal-logo">X</span><small>{direction === "back" ? "RETURNING THROUGH NETWORK" : "ENTERING SENTRIX"}</small></div>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/platform" component={Platform} />
        <Route path="/works/:slug">{(params) => <CaseStudy slug={params.slug} />}</Route>
        <Route path="/login" component={Login} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
